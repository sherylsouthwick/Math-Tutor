﻿namespace CSC236376_ssouthwick_midterm
{
    partial class MathTutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grpbxProblemChoice = new System.Windows.Forms.GroupBox();
            this.rbtnDivision = new System.Windows.Forms.RadioButton();
            this.rbtnMultiplication = new System.Windows.Forms.RadioButton();
            this.rbtnSubtraction = new System.Windows.Forms.RadioButton();
            this.rbtnAddition = new System.Windows.Forms.RadioButton();
            this.btnProblemChoice = new System.Windows.Forms.Button();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpbxSolve = new System.Windows.Forms.GroupBox();
            this.lblRightWrong = new System.Windows.Forms.Label();
            this.lblCorrect = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblP1 = new System.Windows.Forms.Label();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.lblNumberCorrect = new System.Windows.Forms.Label();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.bxAnswer = new System.Windows.Forms.TextBox();
            this.lblProblem = new System.Windows.Forms.Label();
            this.lblInst = new System.Windows.Forms.Label();
            this.lblWhichQ = new System.Windows.Forms.Label();
            this.lblTypeMath = new System.Windows.Forms.Label();
            this.grpbxReport = new System.Windows.Forms.GroupBox();
            this.bxAllScores = new System.Windows.Forms.ListBox();
            this.btnAgain = new System.Windows.Forms.Button();
            this.bxReport = new System.Windows.Forms.ListBox();
            this.lblProgressReport = new System.Windows.Forms.Label();
            this.grpbxGetStudentInfo = new System.Windows.Forms.GroupBox();
            this.lblNameGradeInst = new System.Windows.Forms.Label();
            this.bxName = new System.Windows.Forms.TextBox();
            this.bxGrade = new System.Windows.Forms.TextBox();
            this.lblStudentGrade = new System.Windows.Forms.Label();
            this.lblStudentName = new System.Windows.Forms.Label();
            this.btnGetStudentInfo = new System.Windows.Forms.Button();
            this.lblGetStudentInfo = new System.Windows.Forms.Label();
            this.btnViewAllScores = new System.Windows.Forms.Button();
            this.grpbxProblemChoice.SuspendLayout();
            this.grpbxSolve.SuspendLayout();
            this.grpbxReport.SuspendLayout();
            this.grpbxGetStudentInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(397, 513);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 33);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(12, 539);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "by Sheryl Southwick";
            // 
            // grpbxProblemChoice
            // 
            this.grpbxProblemChoice.Controls.Add(this.rbtnDivision);
            this.grpbxProblemChoice.Controls.Add(this.rbtnMultiplication);
            this.grpbxProblemChoice.Controls.Add(this.rbtnSubtraction);
            this.grpbxProblemChoice.Controls.Add(this.rbtnAddition);
            this.grpbxProblemChoice.Controls.Add(this.btnProblemChoice);
            this.grpbxProblemChoice.Controls.Add(this.lblInstructions);
            this.grpbxProblemChoice.Location = new System.Drawing.Point(521, 101);
            this.grpbxProblemChoice.Name = "grpbxProblemChoice";
            this.grpbxProblemChoice.Size = new System.Drawing.Size(423, 328);
            this.grpbxProblemChoice.TabIndex = 2;
            this.grpbxProblemChoice.TabStop = false;
            this.grpbxProblemChoice.Visible = false;
            // 
            // rbtnDivision
            // 
            this.rbtnDivision.AutoSize = true;
            this.rbtnDivision.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.rbtnDivision.Location = new System.Drawing.Point(213, 184);
            this.rbtnDivision.Name = "rbtnDivision";
            this.rbtnDivision.Size = new System.Drawing.Size(84, 27);
            this.rbtnDivision.TabIndex = 7;
            this.rbtnDivision.Text = "Division";
            this.rbtnDivision.UseVisualStyleBackColor = true;
            // 
            // rbtnMultiplication
            // 
            this.rbtnMultiplication.AutoSize = true;
            this.rbtnMultiplication.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.rbtnMultiplication.Location = new System.Drawing.Point(213, 108);
            this.rbtnMultiplication.Name = "rbtnMultiplication";
            this.rbtnMultiplication.Size = new System.Drawing.Size(128, 27);
            this.rbtnMultiplication.TabIndex = 6;
            this.rbtnMultiplication.Text = "Multiplication";
            this.rbtnMultiplication.UseVisualStyleBackColor = true;
            // 
            // rbtnSubtraction
            // 
            this.rbtnSubtraction.AutoSize = true;
            this.rbtnSubtraction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.rbtnSubtraction.Location = new System.Drawing.Point(33, 184);
            this.rbtnSubtraction.Name = "rbtnSubtraction";
            this.rbtnSubtraction.Size = new System.Drawing.Size(118, 27);
            this.rbtnSubtraction.TabIndex = 5;
            this.rbtnSubtraction.Text = "Subtraction";
            this.rbtnSubtraction.UseVisualStyleBackColor = true;
            // 
            // rbtnAddition
            // 
            this.rbtnAddition.AutoSize = true;
            this.rbtnAddition.Checked = true;
            this.rbtnAddition.ForeColor = System.Drawing.Color.Red;
            this.rbtnAddition.Location = new System.Drawing.Point(33, 108);
            this.rbtnAddition.Name = "rbtnAddition";
            this.rbtnAddition.Size = new System.Drawing.Size(90, 27);
            this.rbtnAddition.TabIndex = 4;
            this.rbtnAddition.TabStop = true;
            this.rbtnAddition.Text = "Addition";
            this.rbtnAddition.UseVisualStyleBackColor = true;
            // 
            // btnProblemChoice
            // 
            this.btnProblemChoice.BackColor = System.Drawing.Color.Yellow;
            this.btnProblemChoice.Location = new System.Drawing.Point(161, 289);
            this.btnProblemChoice.Name = "btnProblemChoice";
            this.btnProblemChoice.Size = new System.Drawing.Size(75, 33);
            this.btnProblemChoice.TabIndex = 0;
            this.btnProblemChoice.Text = "OK";
            this.btnProblemChoice.UseVisualStyleBackColor = false;
            this.btnProblemChoice.Click += new System.EventHandler(this.btnOK_Click_1);
            // 
            // lblInstructions
            // 
            this.lblInstructions.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.ForeColor = System.Drawing.Color.Teal;
            this.lblInstructions.Location = new System.Drawing.Point(29, 26);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(342, 57);
            this.lblInstructions.TabIndex = 1;
            this.lblInstructions.Text = "Please select the type of problems you wish to solve, then press OK.";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Magenta;
            this.lblTitle.Location = new System.Drawing.Point(207, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(132, 30);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Math Tutor";
            // 
            // grpbxSolve
            // 
            this.grpbxSolve.Controls.Add(this.lblRightWrong);
            this.grpbxSolve.Controls.Add(this.lblCorrect);
            this.grpbxSolve.Controls.Add(this.lblCount);
            this.grpbxSolve.Controls.Add(this.lblP2);
            this.grpbxSolve.Controls.Add(this.lblP1);
            this.grpbxSolve.Controls.Add(this.btnAnswer);
            this.grpbxSolve.Controls.Add(this.lblNumberCorrect);
            this.grpbxSolve.Controls.Add(this.lblAnswer);
            this.grpbxSolve.Controls.Add(this.bxAnswer);
            this.grpbxSolve.Controls.Add(this.lblProblem);
            this.grpbxSolve.Controls.Add(this.lblInst);
            this.grpbxSolve.Controls.Add(this.lblWhichQ);
            this.grpbxSolve.Controls.Add(this.lblTypeMath);
            this.grpbxSolve.Location = new System.Drawing.Point(444, 34);
            this.grpbxSolve.Name = "grpbxSolve";
            this.grpbxSolve.Size = new System.Drawing.Size(429, 392);
            this.grpbxSolve.TabIndex = 3;
            this.grpbxSolve.TabStop = false;
            this.grpbxSolve.Visible = false;
            // 
            // lblRightWrong
            // 
            this.lblRightWrong.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRightWrong.ForeColor = System.Drawing.Color.Red;
            this.lblRightWrong.Location = new System.Drawing.Point(27, 203);
            this.lblRightWrong.Name = "lblRightWrong";
            this.lblRightWrong.Size = new System.Drawing.Size(376, 49);
            this.lblRightWrong.TabIndex = 19;
            this.lblRightWrong.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRightWrong.Visible = false;
            // 
            // lblCorrect
            // 
            this.lblCorrect.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorrect.ForeColor = System.Drawing.Color.Green;
            this.lblCorrect.Location = new System.Drawing.Point(206, 307);
            this.lblCorrect.Name = "lblCorrect";
            this.lblCorrect.Size = new System.Drawing.Size(87, 49);
            this.lblCorrect.TabIndex = 18;
            this.lblCorrect.Text = "0";
            this.lblCorrect.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblCorrect.Visible = false;
            // 
            // lblCount
            // 
            this.lblCount.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.ForeColor = System.Drawing.Color.Green;
            this.lblCount.Location = new System.Drawing.Point(30, 307);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(87, 49);
            this.lblCount.TabIndex = 17;
            this.lblCount.Text = "1";
            this.lblCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblCount.Visible = false;
            // 
            // lblP2
            // 
            this.lblP2.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2.ForeColor = System.Drawing.Color.Green;
            this.lblP2.Location = new System.Drawing.Point(90, 105);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(87, 49);
            this.lblP2.TabIndex = 16;
            this.lblP2.Text = "8";
            this.lblP2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblP2.Visible = false;
            // 
            // lblP1
            // 
            this.lblP1.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1.ForeColor = System.Drawing.Color.Green;
            this.lblP1.Location = new System.Drawing.Point(6, 105);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(87, 49);
            this.lblP1.TabIndex = 15;
            this.lblP1.Text = "7";
            this.lblP1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblP1.Visible = false;
            // 
            // btnAnswer
            // 
            this.btnAnswer.BackColor = System.Drawing.Color.Yellow;
            this.btnAnswer.Location = new System.Drawing.Point(270, 166);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(75, 33);
            this.btnAnswer.TabIndex = 1;
            this.btnAnswer.Text = "OK";
            this.btnAnswer.UseVisualStyleBackColor = false;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // lblNumberCorrect
            // 
            this.lblNumberCorrect.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberCorrect.Location = new System.Drawing.Point(254, 356);
            this.lblNumberCorrect.Name = "lblNumberCorrect";
            this.lblNumberCorrect.Size = new System.Drawing.Size(139, 33);
            this.lblNumberCorrect.TabIndex = 12;
            this.lblNumberCorrect.Text = "0 of 0 Correct";
            // 
            // lblAnswer
            // 
            this.lblAnswer.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.ForeColor = System.Drawing.Color.Green;
            this.lblAnswer.Location = new System.Drawing.Point(167, 106);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(87, 49);
            this.lblAnswer.TabIndex = 11;
            this.lblAnswer.Text = "56";
            this.lblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblAnswer.Visible = false;
            // 
            // bxAnswer
            // 
            this.bxAnswer.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bxAnswer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bxAnswer.Location = new System.Drawing.Point(164, 159);
            this.bxAnswer.Name = "bxAnswer";
            this.bxAnswer.Size = new System.Drawing.Size(100, 41);
            this.bxAnswer.TabIndex = 0;
            this.bxAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblProblem
            // 
            this.lblProblem.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProblem.ForeColor = System.Drawing.Color.Green;
            this.lblProblem.Location = new System.Drawing.Point(21, 155);
            this.lblProblem.Name = "lblProblem";
            this.lblProblem.Size = new System.Drawing.Size(147, 49);
            this.lblProblem.TabIndex = 9;
            this.lblProblem.Text = "10 x 10 =";
            this.lblProblem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblInst
            // 
            this.lblInst.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInst.ForeColor = System.Drawing.Color.Red;
            this.lblInst.Location = new System.Drawing.Point(23, 53);
            this.lblInst.Name = "lblInst";
            this.lblInst.Size = new System.Drawing.Size(348, 31);
            this.lblInst.TabIndex = 5;
            this.lblInst.Text = "Enter answer in box, then click OK button.\r\n";
            // 
            // lblWhichQ
            // 
            this.lblWhichQ.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhichQ.Location = new System.Drawing.Point(23, 356);
            this.lblWhichQ.Name = "lblWhichQ";
            this.lblWhichQ.Size = new System.Drawing.Size(176, 33);
            this.lblWhichQ.TabIndex = 4;
            this.lblWhichQ.Text = "Question 1 of 10";
            // 
            // lblTypeMath
            // 
            this.lblTypeMath.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeMath.Location = new System.Drawing.Point(120, 16);
            this.lblTypeMath.Name = "lblTypeMath";
            this.lblTypeMath.Size = new System.Drawing.Size(134, 30);
            this.lblTypeMath.TabIndex = 1;
            this.lblTypeMath.Text = "Addition\r\n";
            this.lblTypeMath.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpbxReport
            // 
            this.grpbxReport.Controls.Add(this.bxAllScores);
            this.grpbxReport.Controls.Add(this.btnAgain);
            this.grpbxReport.Controls.Add(this.bxReport);
            this.grpbxReport.Controls.Add(this.lblProgressReport);
            this.grpbxReport.Location = new System.Drawing.Point(636, 8);
            this.grpbxReport.Name = "grpbxReport";
            this.grpbxReport.Size = new System.Drawing.Size(429, 421);
            this.grpbxReport.TabIndex = 4;
            this.grpbxReport.TabStop = false;
            this.grpbxReport.Text = " ";
            this.grpbxReport.Visible = false;
            // 
            // bxAllScores
            // 
            this.bxAllScores.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bxAllScores.FormattingEnabled = true;
            this.bxAllScores.ItemHeight = 19;
            this.bxAllScores.Location = new System.Drawing.Point(19, 58);
            this.bxAllScores.Name = "bxAllScores";
            this.bxAllScores.Size = new System.Drawing.Size(387, 308);
            this.bxAllScores.TabIndex = 23;
            this.bxAllScores.Visible = false;
            // 
            // btnAgain
            // 
            this.btnAgain.BackColor = System.Drawing.Color.Yellow;
            this.btnAgain.Location = new System.Drawing.Point(174, 381);
            this.btnAgain.Name = "btnAgain";
            this.btnAgain.Size = new System.Drawing.Size(144, 33);
            this.btnAgain.TabIndex = 0;
            this.btnAgain.Text = "Quiz Again";
            this.btnAgain.UseVisualStyleBackColor = false;
            this.btnAgain.Click += new System.EventHandler(this.btnAgain_Click);
            // 
            // bxReport
            // 
            this.bxReport.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bxReport.FormattingEnabled = true;
            this.bxReport.ItemHeight = 27;
            this.bxReport.Location = new System.Drawing.Point(44, 74);
            this.bxReport.Name = "bxReport";
            this.bxReport.Size = new System.Drawing.Size(359, 301);
            this.bxReport.TabIndex = 20;
            // 
            // lblProgressReport
            // 
            this.lblProgressReport.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgressReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblProgressReport.Location = new System.Drawing.Point(55, 26);
            this.lblProgressReport.Name = "lblProgressReport";
            this.lblProgressReport.Size = new System.Drawing.Size(307, 30);
            this.lblProgressReport.TabIndex = 1;
            this.lblProgressReport.Text = "Progress Report";
            this.lblProgressReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpbxGetStudentInfo
            // 
            this.grpbxGetStudentInfo.Controls.Add(this.lblNameGradeInst);
            this.grpbxGetStudentInfo.Controls.Add(this.bxName);
            this.grpbxGetStudentInfo.Controls.Add(this.bxGrade);
            this.grpbxGetStudentInfo.Controls.Add(this.lblStudentGrade);
            this.grpbxGetStudentInfo.Controls.Add(this.lblStudentName);
            this.grpbxGetStudentInfo.Controls.Add(this.btnGetStudentInfo);
            this.grpbxGetStudentInfo.Controls.Add(this.lblGetStudentInfo);
            this.grpbxGetStudentInfo.Location = new System.Drawing.Point(15, 12);
            this.grpbxGetStudentInfo.Name = "grpbxGetStudentInfo";
            this.grpbxGetStudentInfo.Size = new System.Drawing.Size(423, 395);
            this.grpbxGetStudentInfo.TabIndex = 4;
            this.grpbxGetStudentInfo.TabStop = false;
            // 
            // lblNameGradeInst
            // 
            this.lblNameGradeInst.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameGradeInst.ForeColor = System.Drawing.Color.Teal;
            this.lblNameGradeInst.Location = new System.Drawing.Point(80, 226);
            this.lblNameGradeInst.Name = "lblNameGradeInst";
            this.lblNameGradeInst.Size = new System.Drawing.Size(274, 62);
            this.lblNameGradeInst.TabIndex = 14;
            this.lblNameGradeInst.Text = "Enter K for kindergarten, or 1 - 12.";
            this.lblNameGradeInst.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bxName
            // 
            this.bxName.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bxName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bxName.Location = new System.Drawing.Point(141, 113);
            this.bxName.Name = "bxName";
            this.bxName.Size = new System.Drawing.Size(263, 41);
            this.bxName.TabIndex = 0;
            this.bxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bxGrade
            // 
            this.bxGrade.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bxGrade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bxGrade.Location = new System.Drawing.Point(192, 177);
            this.bxGrade.Name = "bxGrade";
            this.bxGrade.Size = new System.Drawing.Size(100, 41);
            this.bxGrade.TabIndex = 1;
            this.bxGrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblStudentGrade
            // 
            this.lblStudentGrade.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentGrade.ForeColor = System.Drawing.Color.Green;
            this.lblStudentGrade.Location = new System.Drawing.Point(17, 173);
            this.lblStudentGrade.Name = "lblStudentGrade";
            this.lblStudentGrade.Size = new System.Drawing.Size(147, 49);
            this.lblStudentGrade.TabIndex = 11;
            this.lblStudentGrade.Text = "grade level";
            this.lblStudentGrade.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblStudentName
            // 
            this.lblStudentName.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentName.ForeColor = System.Drawing.Color.Green;
            this.lblStudentName.Location = new System.Drawing.Point(6, 113);
            this.lblStudentName.Name = "lblStudentName";
            this.lblStudentName.Size = new System.Drawing.Size(158, 49);
            this.lblStudentName.TabIndex = 10;
            this.lblStudentName.Text = "first name";
            this.lblStudentName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnGetStudentInfo
            // 
            this.btnGetStudentInfo.BackColor = System.Drawing.Color.Yellow;
            this.btnGetStudentInfo.Location = new System.Drawing.Point(161, 336);
            this.btnGetStudentInfo.Name = "btnGetStudentInfo";
            this.btnGetStudentInfo.Size = new System.Drawing.Size(75, 33);
            this.btnGetStudentInfo.TabIndex = 2;
            this.btnGetStudentInfo.Text = "OK";
            this.btnGetStudentInfo.UseVisualStyleBackColor = false;
            this.btnGetStudentInfo.Click += new System.EventHandler(this.btnGetStudentInfo_Click);
            // 
            // lblGetStudentInfo
            // 
            this.lblGetStudentInfo.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGetStudentInfo.ForeColor = System.Drawing.Color.Red;
            this.lblGetStudentInfo.Location = new System.Drawing.Point(33, 32);
            this.lblGetStudentInfo.Name = "lblGetStudentInfo";
            this.lblGetStudentInfo.Size = new System.Drawing.Size(342, 57);
            this.lblGetStudentInfo.TabIndex = 1;
            this.lblGetStudentInfo.Text = "To begin, enter your first name and grade level, and press OK.\r\n";
            // 
            // btnViewAllScores
            // 
            this.btnViewAllScores.BackColor = System.Drawing.Color.Aquamarine;
            this.btnViewAllScores.Location = new System.Drawing.Point(157, 472);
            this.btnViewAllScores.Name = "btnViewAllScores";
            this.btnViewAllScores.Size = new System.Drawing.Size(191, 33);
            this.btnViewAllScores.TabIndex = 0;
            this.btnViewAllScores.Text = "VIEW ALL SCORES";
            this.btnViewAllScores.UseVisualStyleBackColor = false;
            this.btnViewAllScores.Click += new System.EventHandler(this.btnViewAllScores_Click);
            // 
            // MathTutor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1077, 739);
            this.Controls.Add(this.btnViewAllScores);
            this.Controls.Add(this.grpbxProblemChoice);
            this.Controls.Add(this.grpbxSolve);
            this.Controls.Add(this.grpbxReport);
            this.Controls.Add(this.grpbxGetStudentInfo);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "MathTutor";
            this.ShowInTaskbar = false;
            this.Text = "Math Tutor";
            this.grpbxProblemChoice.ResumeLayout(false);
            this.grpbxProblemChoice.PerformLayout();
            this.grpbxSolve.ResumeLayout(false);
            this.grpbxSolve.PerformLayout();
            this.grpbxReport.ResumeLayout(false);
            this.grpbxGetStudentInfo.ResumeLayout(false);
            this.grpbxGetStudentInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpbxProblemChoice;
        private System.Windows.Forms.RadioButton rbtnDivision;
        private System.Windows.Forms.RadioButton rbtnMultiplication;
        private System.Windows.Forms.RadioButton rbtnSubtraction;
        private System.Windows.Forms.RadioButton rbtnAddition;
        private System.Windows.Forms.Button btnProblemChoice;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpbxSolve;
        private System.Windows.Forms.TextBox bxAnswer;
        private System.Windows.Forms.Label lblProblem;
        private System.Windows.Forms.Label lblInst;
        private System.Windows.Forms.Label lblWhichQ;
        private System.Windows.Forms.Label lblTypeMath;
        private System.Windows.Forms.Label lblNumberCorrect;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblCorrect;
        private System.Windows.Forms.GroupBox grpbxReport;
        private System.Windows.Forms.Label lblProgressReport;
        private System.Windows.Forms.Label lblRightWrong;
        private System.Windows.Forms.GroupBox grpbxGetStudentInfo;
        private System.Windows.Forms.Label lblNameGradeInst;
        private System.Windows.Forms.TextBox bxName;
        private System.Windows.Forms.TextBox bxGrade;
        private System.Windows.Forms.Label lblStudentGrade;
        private System.Windows.Forms.Label lblStudentName;
        private System.Windows.Forms.Button btnGetStudentInfo;
        private System.Windows.Forms.Label lblGetStudentInfo;
        private System.Windows.Forms.ListBox bxReport;
        private System.Windows.Forms.Button btnAgain;
        private System.Windows.Forms.Button btnViewAllScores;
        private System.Windows.Forms.ListBox bxAllScores;
    }
}

