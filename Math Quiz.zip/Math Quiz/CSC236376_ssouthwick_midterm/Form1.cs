﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CSC236376_ssouthwick_midterm
{
    public partial class MathTutor : Form
    {
        public MathTutor()
        {
            InitializeComponent();
        }

        private async void WaitASec()
        {
            await Task.Delay(3000);
        }

        private void btnGetStudentInfo_Click(object sender, EventArgs e)
        {
            // ValidateNameAndGradeInput();
            int grade;
            if (String.Compare(bxName.Text, "aa") <= 0)
            {
                lblNameGradeInst.Text = "Enter your name.";
                int a = 1;  a ++; a--; WaitASec();

               // MessageBox.Show("Enter your name.");
                bxName.Text = ""; lblNameGradeInst.Text = "Enter K for kindergarten, or 1 - 12.";
            }


            else if (int.TryParse(bxGrade.Text, out grade) && (grade < 1 || grade > 12))
            {
                MessageBox.Show("Enter your grade.");
                bxGrade.Text = "";

            }

            else if (!int.TryParse(bxGrade.Text, out grade))
            {
                if (bxGrade.Text != "k" && bxGrade.Text != "K")
                {
                    MessageBox.Show("Enter your grade.");
                    bxGrade.Text = "";
                }
                else
                {
                    grpbxGetStudentInfo.Visible = false;
                    grpbxProblemChoice.Visible = true;
                }
            }

            else
            {
                grpbxGetStudentInfo.Visible = false;
                grpbxProblemChoice.Visible = true;

            }

        }


        // Choose math operation to quiz.
        private void btnOK_Click_1(object sender, EventArgs e)
        {
            // Hide Choice, show Solve.
            grpbxProblemChoice.Visible = false; grpbxSolve.Visible = true; 
            bxAnswer.Text = ""; lblCorrect.Text = "0"; lblCount.Text = "1";


            // Determine which math operation to execute.
            Choice();


        }

        // Execute selected math operation quiz.
        private void Choice()
        {
            // Addition is selected.
            if (rbtnAddition.Checked)
            {
                // Create addition problem and solution.	
                Addition();
            }
            // Subtraction is selected.
            else if (rbtnSubtraction.Checked)
            {

                // Create subtraction problem and solution.
                Subtraction();
            }
            // Multiplication is selected.
            else if (rbtnMultiplication.Checked)
            {
                // Create multiplication problem and solution.
                Multiplication();
            }
            // Division is selected.
            else
            {
                // Create division problem and solution..
                Division();

            }
        }


        // Create addition problem and solution.
        private void Addition()
        {

            lblTypeMath.Text = "Addition";

            Random problem = new Random();
            int count = int.Parse(lblCount.Text);

            lblWhichQ.Text = ("Question " + count + " of 10");
            int addend1 = problem.Next(899) + 100; int addend2 = problem.Next(899) + 100;

            lblProblem.Text = (addend1.ToString() + " + " + addend2.ToString() + " = ");
            int sum = addend1 + addend2; lblAnswer.Text = sum.ToString();
            lblP1.Text = addend1.ToString(); lblP2.Text = addend2.ToString();

        }
        // Create subtraction problem and solution.
        private void Subtraction()
        {
            lblTypeMath.Text = "Subtraction";


            Random problem = new Random();
            int count = int.Parse(lblCount.Text);

            lblWhichQ.Text = ("Question " + count + " of 10");
            int menuend = problem.Next(899) + 100; int subtrahend = problem.Next(899) + 100;
            if (subtrahend > menuend)
            {

                int temp = menuend; menuend = subtrahend; subtrahend = temp;
            }
            lblProblem.Text = (menuend.ToString() + " - " + subtrahend.ToString() + " = ");
            int difference = menuend - subtrahend; lblAnswer.Text = difference.ToString();
            lblP1.Text = menuend.ToString(); lblP2.Text = subtrahend.ToString();
        }

        // Create multiplication problem and solution.
        private void Multiplication()
        {
            lblTypeMath.Text = "Multiplication";

            Random problem = new Random();
            int count = int.Parse(lblCount.Text);

            lblWhichQ.Text = ("Question " + count + " of 10");
            int multiplicand = problem.Next(12) + 1; int multiplier = problem.Next(12) + 1;

            lblProblem.Text = (multiplicand.ToString() + " x " + multiplier.ToString() + " = ");
            int product = multiplicand * multiplier; lblAnswer.Text = product.ToString();
            lblP1.Text = multiplicand.ToString(); lblP2.Text = multiplier.ToString();


        }

        // Create division problem and solution.
        private void Division()
        {
            lblTypeMath.Text = "Division";

            Random problem = new Random();
            int count = int.Parse(lblCount.Text);

            lblWhichQ.Text = ("Question " + count + " of 10");
            int divisor = problem.Next(10) + 3; int quotient = problem.Next(10) + 1;
            while (divisor * quotient > 99)
            {
                quotient = problem.Next(10) + 1;
            }
            int dividend = quotient * divisor;
            lblProblem.Text = (dividend.ToString() + " ÷ " + divisor.ToString() + " = ");

            lblAnswer.Text = quotient.ToString();
            lblP1.Text = dividend.ToString(); lblP2.Text = divisor.ToString();

        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {

            ValidateAnswerInput();

        }

        private void ValidateAnswerInput()
        {
            int answer;
            if (!int.TryParse(bxAnswer.Text, out answer))
            {
                bxAnswer.Text = "";
                lblRightWrong.Text = "Enter a whole number."; lblRightWrong.Visible = true;
                MessageBox.Show("Please enter a whole number.");
                lblRightWrong.Visible = false;

            }
            else CheckAnswer();

        }


        private void CheckAnswer()
        {


            int count = int.Parse(lblCount.Text);
            int correct = int.Parse(lblCorrect.Text);
            int answer; int.TryParse(bxAnswer.Text, out answer);
            int solution = int.Parse(lblAnswer.Text);
            if (answer == solution)
            {

                correct++; lblCorrect.Text = correct.ToString();
                 lblRightWrong.Text = "Right!"; lblRightWrong.Visible = true;
                lblNumberCorrect.Text = (correct + " of " + count + " Correct");
                MessageBox.Show("Right!");
                lblRightWrong.Visible = false;

            }
            else
            {
                lblCorrect.Text = correct.ToString();
                lblNumberCorrect.Text = (correct + " of " + count + " Correct");
                lblRightWrong.Text = "answer: " + solution; lblRightWrong.Visible = true;
                MessageBox.Show("answer: " + solution);
                lblRightWrong.Visible = false;

            }

            RepeatLoop(count);

        }

        private void RepeatLoop(int count)
        {

            if (count < 10)
            {
                count++; lblCount.Text = count.ToString(); bxAnswer.Text = "";
                Choice();
            }
            else
            {
                GenerateReport();
            }
        }

        private void GenerateReport()
        {

            btnAgain.Text = "Quiz Again"; grpbxReport.Visible = true; grpbxSolve.Visible = false;
            lblProgressReport.Text = lblProgressReport.Text + "Progress Report";
            bxReport.Items.Clear();
            int correct; int.TryParse(lblCorrect.Text, out correct);
            bxReport.Items.Add(bxName.Text);
            bxReport.Items.Add("Grade " + bxGrade.Text);
            bxReport.Items.Add ( "10 Total Questions");
            bxReport.Items.Add(correct + " Correct");
            bxReport.Items.Add((10 - correct)+ " Incorrect ");

            SaveReportToFile();

        }

        private void SaveReportToFile()
        {
            int correct; int.TryParse(lblCorrect.Text, out correct); int incorrect = 10 - correct;
            string reportline = bxName.Text + " Grade " + bxGrade.Text + " " +
                lblTypeMath.Text + "\n	10 Total Questions, "
                +   correct.ToString("d2") + " Correct, " + incorrect.ToString("d2") + " Incorrect ";
            // Declare a StreamWriter Variable. Create a file and get a StreamWriter object.
            StreamWriter outputFile = File.AppendText("Report.txt");

            // Write report info to file.Close the file.
            outputFile.WriteLine(reportline); outputFile.Close();

            // Inform user report was written.
            MessageBox.Show("report was written.");
        }

        private void btnAgain_Click(object sender, EventArgs e)
        {
            bxReport.Visible = true; bxAllScores.Visible = false;
            grpbxReport.Visible = false;
            if (String.Compare(bxName.Text, "aa") <= 0)
            {
                grpbxGetStudentInfo.Visible = true;
            }
            else
            {
                grpbxProblemChoice.Visible = true;
            }    
        }

        private void btnViewAllScores_Click(object sender, EventArgs e)
        {

            if (String.Compare(bxName.Text, "aa") <= 0)
            {
                btnAgain.Text = " Start QUIZ";
            }
            
            //READ from file.
            try
            {
                // Declare a  readline Variable.
                string thisline; string all_lines = "All Scores\n\n";

                // Declare a StreamReader Variable.
                StreamReader inputFile;

                // Open file and get StreamReader object.
                inputFile = File.OpenText("Report.txt");

                // Clear listbox. 
                bxAllScores.Items.Clear();

                // Read file contents.
                while (!inputFile.EndOfStream)
                {
                    //  Get line of data and add to MessageBox.
                    thisline = inputFile.ReadLine();
                    all_lines += thisline + "\n";

                    // Add line of data to listbox.
                    bxAllScores.Items.Add(thisline);
                }

                // Close the file.
                inputFile.Close();
                grpbxSolve.Visible = false; grpbxGetStudentInfo.Visible = false;
                grpbxProblemChoice.Visible = false; grpbxReport.Visible = true;
                lblProgressReport.Text = "All Scores";
                bxReport.Visible = false; bxAllScores.Visible = true;
                MessageBox.Show(all_lines);

            }
            catch
            {
                MessageBox.Show("oops.");
            }
        }

        // Exit program.
        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the form.
            this.Close();
        }

    }
}

